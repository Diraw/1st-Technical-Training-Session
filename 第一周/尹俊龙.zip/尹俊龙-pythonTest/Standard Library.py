import os
import glob

# 操作系统接口
current_dir = os.getcwd()
print("当前工作目录:", current_dir)

files = os.listdir(current_dir)
print("目录下的文件:", files)

print(glob.glob("*.py"))

# 访问互联网
# import unittest.main
# from urllib.request import urlopen
# for line in urlopen("https://www....."):
#     line = line.decode("utf-8")
#     if "EST" in line or "EDT" in line:
#         print(line)

# 模块测试
import unittest
def average(values):
    return sum(values) / len(values)

class TestStatisticalFunctions(unittest.TestCase):
    def test_average(self):
        self.assertEqual(average([20, 30, 70]), 40.0)
        self.assertEqual(round(average([1, 5, 7]), 1), 4.3)

unittest.main()
