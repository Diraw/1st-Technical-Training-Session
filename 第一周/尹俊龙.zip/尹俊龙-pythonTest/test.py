# tup1 = (1, 2)
# tup2 = (1,234,5)
# print(tup1 + tup2)
# # del tup1
# print(tup1)
# tup3 = tup1*2
# print(tup3)
dit2 = {1 : "Jack",
        2 : "Alan"} 
dit3 = {"name" : "Jsds",
        "ID" : 29339131321}
del dit3["name"]
print(dit3)
print(dit2[1])
# dit2[1] = "skadas"
# print(type(dit2))
if "Jack" in dit2:
    print("yes")
# print(dit2[1])

print("-------------------------------------")
#  set的使用
s = set(("Google", "TaoBao", "PDD"))
print(s)
s.remove("Google")
print(f"{s}, {len(s)}")

# 字典推导式, 把列表转换为字典
listdemo = ["Google", "Runoob", "Taobao"]
newdict = {key : len(key) for key in listdemo} 
print(newdict)

# 判断不是 abc 的字母输出
a = {x for x in "abcasasadas" if x not in 'abc'}
print(a)

list = [1, 2, 3, 4]
it = iter(list)
print(next(it))
for x in it:
     print(x, end = " ")
print("------------------------")

# 使用 yield 实现斐波那契数列 
import sys
def fibnacci(n):
    a, b, counter = 0, 1, 0
    while True:
        if(counter > n):
            return
        yield a
        a, b = b, a + b
        counter += 1
f = fibnacci(10)
while True:
    try:
        print(next(f), end = " ")
    except StopIteration:
        sys.exit()


     
