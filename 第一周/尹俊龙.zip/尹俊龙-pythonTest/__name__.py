import lambda1

# print(f"模块的 __name__ 值: {__name__}")
def greet():
    print("来自 example 模块的问候")

if __name__ == "__main__":
    print("该脚本正在直接运行")
    greet()
else:
    print("该脚本作为模块被导入")

