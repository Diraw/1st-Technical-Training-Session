from functools import reduce

if __name__ == "__main__":
    f = lambda : "hello, world"
    print(f())

    x = lambda a : a + 10
    print(x(5))

    x = lambda a, b : a * b
    print(x(2, 4))

    numbers = [1, 2, 3, 4, 5]
    squared = list(map(lambda x : x**2, numbers))  # map(function, iterable)
    print(squared)

    evenNumbers = list(filter(lambda x : x % 2 == 0, numbers))
    print(evenNumbers)

    product = reduce(lambda x, y : x*y, numbers)
    print(product)

