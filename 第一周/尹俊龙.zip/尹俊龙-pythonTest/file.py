import sys
try:
    with open("myfile.txt",encoding = 'utf-8') as f:
        s = f.readline()
        i = int(s.strip())
except OSError as e:
    print("OSError :{0}".format(e))
except ValueError as e:
    print(e)
except:
    print("Unexpeced error")

