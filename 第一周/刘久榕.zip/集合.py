#注意：创建一个空集合必须用 set() 而不是 { }，因为 { } 是用来创建一个空字典。

# 集合的常用操作示例

# 1. 创建集合
s1 = {1, 2, 3, 4, 5}  # 直接使用大括号
s2 = set([3, 4, 5, 6])  # 使用 set() 进行转换
s3 = set()  # 创建空集合（{} 代表空字典）

# 2. 添加元素
s1.add(6)  # 添加单个元素
s1.update([7, 8, 9])  # 添加多个元素

# 3. 删除元素
s1.remove(3)  # 删除 3（如果不存在会报错）
s1.discard(10)  # 删除 10（如果不存在不会报错）
s1.pop()  # 随机删除一个元素

# 4. 集合运算
a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
intersection = a & b  # 交集
difference = a - b  # 差集
union = a | b  # 并集
symmetric_diff = a ^ b  # 对称差集

# 5. 判断子集、超集和无交集
is_subset = a.issubset(b)  # a 是否是 b 的子集
is_superset = b.issuperset(a)  # b 是否是 a 的超集
is_disjoint = a.isdisjoint({7, 8, 9})  # 是否无交集

# 6. 遍历集合
for item in a:
    print(item)

# 7. 复制集合
s_copy = a.copy()

# 8. 长度计算
length = len(a)

# 9. 成员检测
contains_3 = 3 in a
contains_10 = 10 in a

# 10. 不可变集合 frozenset
fs = frozenset([1, 2, 3, 4])  # frozenset 不能修改
