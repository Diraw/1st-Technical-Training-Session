#还有一种就是参数带两个星号 **基本语法如下：

# 可写函数说明
def printinfo( arg1, **vardict ):
   "打印任何传入的参数"
   print ("输出: ")
   print (arg1)
   print (vardict)
 
# 调用printinfo 函数
printinfo(1, a=2,b=3)


'''
Python 使用 lambda 来创建匿名函数。
所谓匿名，意即不再使用 def 语句这样标准的形式定义一个函数。
lambda 只是一个表达式，函数体比 def 简单很多。
lambda 的主体是一个表达式，而不是一个代码块。仅仅能在 lambda 表达式中封装有限的逻辑进去。
lambda 函数拥有自己的命名空间，且不能访问自己参数列表之外或全局命名空间里的参数。
'''

# 可写函数说明
sum = lambda arg1, arg2: arg1 + arg2#lambda+参与函数的变量+函数
 
# 调用sum函数
print ("相加后的值为 : ", sum( 10, 20 ))
print ("相加后的值为 : ", sum( 20, 20 ))

#我们可以将匿名函数封装在一个函数内，这样可以使用同样的代码来创建多个匿名函数。

#以下实例将匿名函数封装在 myfunc 函数中，通过传入不同的参数来创建不同的匿名函数：
def myfunc(n):
  return lambda a : a * n
 #产出多个模型
mydoubler = myfunc(2)
mytripler = myfunc(3)
 
print(mydoubler(11))
print(mytripler(11))

#lambda 函数通常与内置函数如 map()、filter() 和 reduce() 一起使用，以便在集合上执行操作。例如：
numbers = [1, 2, 3, 4, 5]
squared = list(map(lambda x: x**2, numbers))#map() 函数用于将一个指定函数应用于给定的可迭代对象（如列表）的每一个元素。
print(squared)  # 输出: [1, 4, 9, 16, 25]

numbers = [1, 2, 3, 4, 5, 6, 7, 8]
even_numbers = list(filter(lambda x: x % 2 == 0, numbers))#filter(function, iterable) 是 Python 的一个内置函数，用于构造一个迭代器，该迭代器会根据 function 的返回值来过滤 iterable 中的元素。
print(even_numbers)  # 输出：[2, 4, 6, 8]


from functools import reduce
 
numbers = [1, 2, 3, 4, 5]
 
# 使用 reduce() 和 lambda 函数计算乘积
#reduce 是一个高阶函数，用于将一个二元函数（即接受两个参数的函数）作用于一个序列的元素上，从第一个元素开始，依次将元素与其前一个结果进行累加操作，最终返回一个单一值。
product = reduce(lambda x, y: x * y, numbers)
 
print(product)  # 输出：120