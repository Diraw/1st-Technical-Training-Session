'''
Python 中的变量不需要声明。每个变量在使用前都必须赋值，变量赋值以后该变量才会被创建。

在 Python 中，变量就是变量，它没有类型，我们所说的"类型"是变量所指的内存中对象的类型。
'''

'''
可变数据类型:字符串、列表、元组都是可变数据类型，这意味着它们的内容可以改变。
不可变数据类型：整数、浮点数、布尔值、字符串、元组、 frozenset 都是不可变数据类型，这意味着它们的内容不能改变。
'''


'''
isinstance 和 type 的区别在于：
type()不会认为子类是一种父类类型。
isinstance()会认为子类是一种父类类型。
'''
class Animal:
    # 定义一个名为 Animal 的基类
    pass
 
class Dog(Animal):
    # 定义一个名为 Dog 的子类，继承自 Animal 类
    pass

# 创建 Animal 和 Dog 的实例
a = Animal()
d = Dog()

# 使用 type() 判断
print(type(a) == Animal)  # 输出: True
print(type(d) == Animal)  # 输出: False
print(type(d) == Dog)     # 输出: True

# 使用 isinstance() 判断
print(isinstance(a, Animal))  # 输出: True
print(isinstance(d, Animal))  # 输出: True
print(isinstance(d, Dog))     # 输出: True
#注意：是类中的对象和父类有继承关系，而不是类和类有继承关系
#注意：Python3 中，bool 是 int 的子类，True 和 False 可以和数字相加， 
#True==1、False==0 会返回 True，但可以通过 is 来判断类型。
print(isinstance(True, int))#输出: True
print(isinstance(False, int))# 输出: True
#类里面的对象和父类有继承关系，则其类称为子类
issubclass(bool, int) # 输出: True


# 加法
result_add = 5 + 4
print(result_add)  # 输出: 9

# 减法
result_subtract = 4.3 - 2
print(result_subtract)  # 输出: 2.3

# 乘法
result_multiply = 3 * 7
print(result_multiply)  # 输出: 21

# 除法，得到一个浮点数
result_divide_float = 2 / 4
print(result_divide_float)  # 输出: 0.5

# 除法，得到一个整数，向下取整数
result_divide_int = 2 // 4
print(result_divide_int)  # 输出: 0

# 取余
result_modulus = 17 % 3
print(result_modulus)  # 输出: 2

# 乘方
result_power = 2 ** 5
print(result_power)  # 输出: 32


#Python可以同时为多个变量赋值，如a, b = 1, 2。
a, b = 1, 2
print(a)  # 输出: 1
print(b)  # 输出: 2


'''
“and:只有当 A 和 B 都满足时，整体条件才满足”。
“or:只要 A 或 B 有一个满足，整体条件就满足”。
“not:取反，如果 A 满足，则整体条件不满足，反之亦然。”
运算级:not > and > or
'''
a = True
b = False

print(a and b)  # 输出: False
print(a or b)   # 输出: True
print(not a)    # 输出: False
print(not b)    # 输出: True


#如果第三个参数为负数表示逆向读取，以下实例用于翻转字符串：
def reverseWords(input): 
      
    # 通过空格将字符串分隔符，把各个单词分隔为列表
    inputWords = input.split(" ") 
  
    # 翻转字符串
    # 假设列表 list = [1,2,3,4],  
    # list[0]=1, list[1]=2 ，而 -1 表示最后一个元素 list[-1]=4 ( 与 list[3]=4 一样) 
    # inputWords[-1::-1] 有三个参数
    # 第一个参数 -1 表示最后一个元素
    # 第二个参数为空，表示移动到列表末尾
    # 第三个参数为步长，-1 表示逆向
    inputWords=inputWords[-1::-1] 
  
    # 重新组合字符串
    output = ' '.join(inputWords) 
      
    return output 
  
if __name__ == "__main__": 
    #确保只有在直接运行 python基本数据类型.py 这个文件时，才会执行翻转字符串的示例代码。
    # 如果这个文件被其他 Python 文件通过 import 语句导入，那么翻转字符串的示例代码将不会被执行。
    input = 'I like runoob'
    rw = reverseWords(input) 
    print(rw)


'''
如果你想创建只有一个元素的元组，需要注意在元素后面添加一个逗号，以区分它是一个元组而不是一个普通的值，
这是因为在没有逗号的情况下，Python会将括号解释为数学运算中的括号，而不是元组的表示。
如果不添加逗号，如下所示，它将被解释为一个普通的值而不是元组：
'''
not_a_tuple = (42)  # 这是一个普通的值，不是元组


# set可以进行集合运算
a = set('abracadabra')
b = set('alacazam')
print(a)
print(a - b)     # a 和 b 的差集
print(a | b)     # a 和 b 的并集
print(a & b)     # a 和 b 的交集
print(a ^ b)     # a 和 b 中不同时存在的元素


#eval() 函数用来执行一个字符串表达式，并返回表达式的值。
#字符串表达式可以包含变量、函数调用、运算符和其他 Python 语法元素。


'''
"较高数据类型"和"较低数据类型"是在隐式类型转换中用于描述数据精度的概念。
精度可以理解为数据类型能够表示的信息量或详细程度。
在Python中，数据类型的"高"和"低"主要根据它们的精度来判断。

这里的"较高"数据类型指的是能够表示更多信息（或更精确信息）的数据类型，
而"较低"的数据类型则表示的信息较少。

Python的数据类型的"高低"可以按照如下顺序理解：
布尔（bool）< 整型（int） < 浮点型（float）< 复数（complex）。
'''