'''
海象运算符的主要目的是在表达式中同时进行赋值和返回赋值的值。
使用海象运算符可以在一些情况下简化代码，尤其是在需要在表达式中使用赋值结果的情况下。
这对于简化循环条件或表达式中的重复计算很有用。
'''
# 使用海象运算符的示例
data = [1, 2, 3, 4, 5, 6, 7]
if (n := len(data)) > 5:
    print(f"列表中有 {n} 个元素")
# 不使用海象运算符的写法
data = [1, 2, 3, 4, 5, 6, 7]
n = len(data)
if n > 5:
    print(f"列表中有 {n} 个元素")


'''
身份运算符用于比较两个对象是否为同一个对象，也就是说，它们是否占用相同的内存地址。

Python 中的身份运算符主要有两个：
is：当两个变量引用的是同一对象时，返回 True。
is not：与 is 相反，当两个变量引用的不是同一对象时，返回 True。
与 == 运算符不同，后者比较的是两个对象的值是否相等，
而身份运算符比较的是对象的标识（内存地址）。
'''
#检查对象是否为 None
if variable is None:
    print("变量为 None")

#比较内置不可变对象
#对于一些不可变对象（如小整数、短字符串等），Python 有时会进行缓存，因此不同变量可能引用相同的对象。
# 但这并不是判断数值相等的依据
a = 256
b = 256
print(a is b)  # 可能为 True，因为小整数常被缓存

a = 257
b = 257
print(a is b)  # 可能为 False，因为较大整数不一定被缓存


#比较运算符
#!/usr/bin/python3
 
a = 21
b = 10
c = 0
 
if ( a == b ):
   print ("1 - a 等于 b")
else:
   print ("1 - a 不等于 b")
 
if ( a != b ):
   print ("2 - a 不等于 b")
else:
   print ("2 - a 等于 b")
 
if ( a < b ):
   print ("3 - a 小于 b")
else:
   print ("3 - a 大于等于 b")
 
if ( a > b ):
   print ("4 - a 大于 b")
else:
   print ("4 - a 小于等于 b")


#使用 \r 实现百分比进度：
import time
import sys

def process_images(image_list):
    """
    模拟批量图片处理，每处理一张图片更新一次进度显示。
    
    参数:
        image_list: 待处理的图片文件名列表
    """
    total = len(image_list)
    for idx, image in enumerate(image_list, start=1):
        # 模拟图片处理（例如：滤镜、缩放、格式转换等）
        time.sleep(0.1)  # 模拟处理时间
        
        # 计算当前处理进度的百分比
        progress = int((idx / total) * 100)
        
        # 构造进度条显示信息
        sys.stdout.write(f"\rProcessing {idx}/{total} images - {progress:3d}% complete")
        sys.stdout.flush()
    
    # 处理完成后换行
    print("\nAll images have been processed!")

# 示例：构造一组待处理图片的文件名
images = [f"image_{i}.jpg" for i in range(1, 21)]
process_images(images)


import time

for i in range(101):
    print("\r{:3}%".format(i),end=' ')
    time.sleep(0.05)

#转义运算符
print('\'Hello, world!\'')  # 输出：'Hello, world!'

print("Hello, world!\nHow are you?")  # 输出：Hello, world!
                                        #       How are you?

print("Hello, world!\tHow are you?")  # 输出：Hello, world!    How are you?

print("Hello,\b world!")  # 输出：Hello world!

print("Hello,\f world!")  # 输出：
                           # Hello,
                           #  world!

print("A 对应的 ASCII 值为：", ord('A'))  # 输出：A 对应的 ASCII 值为： 65

print("\x41 为 A 的 ASCII 代码")  # 输出：A 为 A 的 ASCII 代码

decimal_number = 42
binary_number = bin(decimal_number)  # 十进制转换为二进制
print('转换为二进制:', binary_number)  # 转换为二进制: 0b101010

octal_number = oct(decimal_number)  # 十进制转换为八进制
print('转换为八进制:', octal_number)  # 转换为八进制: 0o52

hexadecimal_number = hex(decimal_number)  # 十进制转换为十六进制
print('转换为十六进制:', hexadecimal_number) # 转换为十六进制: 0x2a


