#多行字符串
para_str = """这是一个多行字符串的实例
多行字符串可以使用制表符
TAB ( \t )。
也可以使用换行符 [ \n ]。
"""
print (para_str)


#字符串处理函数
'''
大小写转换方法
upper()： 将字符串中所有字符转换为大写。
lower()： 将字符串中所有字符转换为小写。
title()： 将字符串转换为标题格式（每个单词首字母大写）。
capitalize()： 仅将字符串首字母转换为大写，其余小写。
'''
s = "hello, python!"

print(s.upper())       # 输出: "HELLO, PYTHON!"
print(s.lower())       # 输出: "hello, python!"
print(s.title())       # 输出: "Hello, Python!"
print(s.capitalize())  # 输出: "Hello, python!"

'''
find(sub)： 返回子串 sub 在字符串中第一次出现的位置，找不到则返回 -1。
index(sub)： 与 find() 类似，但找不到时会引发 ValueError 异常。
'''
s = "Hello, Python!"

print(s.find("Python"))  # 输出: 7
print(s.find("Java"))    # 输出: -1

# 使用 index() 找不到子串时会报错
try:
    print(s.index("Java"))
except ValueError as e:
    print("未找到子串:", e)

#replace()：替换字符串中的子串，将旧子串替换为新子串。
s = "Hello, Python!"
new_s = s.replace("Python", "World")
print(new_s)  # 输出: "Hello, World!"

'''
split(sep)： 根据指定分隔符 sep 分割字符串，返回列表。如果不指定分隔符，默认按空白字符分割。
join(iterable)： 将序列中的多个字符串通过指定的连接符连接成一个新的字符串。
'''
# split 示例
s = "apple,banana,cherry"
fruits = s.split(",")
print(fruits)  # 输出: ['apple', 'banana', 'cherry']

# join 示例
joined = "-".join(fruits)
print(joined)  # 输出: "apple-banana-cherry"

'''
strip()： 去除字符串首尾的空白字符（包括空格、换行、制表符等）。
lstrip()： 去除字符串左侧空白字符。
rstrip()： 去除字符串右侧空白字符。
'''
s = "   Hello, Python!   \n"
print(s.strip())   # 输出: "Hello, Python!"
print(s.lstrip())  # 输出: "Hello, Python!   \n"
print(s.rstrip())  # 输出: "   Hello, Python!"

'''
格式化字符串指的是在一个字符串模板中预留位置（占位符），
在运行时将变量或表达式的值嵌入到字符串中，生成一个新的字符串。
'''
name = "Bob"
age = 25
s = "My name is {} and I am {} years old.".format(name, age)
print(s)  # 输出: My name is Bob and I am 25 years old.
#从 Python 3.6 开始，可以在字符串前加上 f 前缀，然后直接在字符串中用大括号 {} 嵌入变量或表达式：
name = "Charlie"
age = 35
s = f"My name is {name} and I am {age} years old."
print(s)  # 输出: My name is Charlie and I am 35 years old.
