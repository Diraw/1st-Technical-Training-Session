#在 Python 中，可以使用 try/except 语句来捕获并处理异常。最简单的形式如下：
'''
try:
    # 可能会抛出异常的代码块
except SomeException:
    # 处理该类型异常的代码'
'''
try:
    result = 10 / 0  # 这里会触发 ZeroDivisionError
    print("这一行不会执行，因为上面发生了异常。")
except ZeroDivisionError:
    print("捕获到除零异常！")

#多个 except 捕获不同类型的异常
try:
    x = int(input("请输入一个整数："))
    result = 10 / x
    print("结果是:", result)
except ValueError:
    print("输入的不是有效整数！")
except ZeroDivisionError:
    print("不可以用0来做除数！")

#同时捕获多个异常
#有时不同异常类型需要执行相同的处理逻辑，可以在同一个 except 中同时指定多个异常类型：
try:
    result = 10 / int(input("请输入一个整数："))
except (ValueError, ZeroDivisionError):
    print("发生了ValueError或ZeroDivisionError异常，处理方式相同。")
#else 子句
#Python 的 try/except 还提供了一个可选的 else 子句，用于在没有发生异常时执行额外的语句：
try:
    result = 10 / 2
except ZeroDivisionError:
    print("出现了除零错误")
else:
    # 如果没有异常，就会执行这里
    print("没有异常，result =", result)

#finally 子句
#无论是否发生异常，都希望执行一些“清理”操作时，可以使用 finally 子句：
try:
    f = open("test.txt", "r")
    data = f.read()
    print("文件内容:", data)
except FileNotFoundError:
    print("文件不存在！")
finally:
    # 无论是否异常，都执行这里
    print("finally子句：进行资源释放等操作")
    if 'f' in locals() and not f.closed:#'f' in locals()用于检查变量f是否在当前作用域中定义。
        f.close()


def compute_ratio_from_file(filename):
    try:
        f = open(filename, "r")
        content = f.read().strip()
        number = int(content)          # 可能抛出 ValueError
        result = 100 / number         # 可能抛出 ZeroDivisionError
    except FileNotFoundError:
        print("文件未找到，请检查文件路径。")
        return None
    except ValueError:
        print("文件内容无法转换为整数。")
        return None
    except ZeroDivisionError:
        print("分母不能为0！")
        return None
    else:
        # 没有发生异常
        return result
    finally:
        # 无论是否发生异常，都执行这里
        if 'f' in locals() and not f.closed:
            f.close()
