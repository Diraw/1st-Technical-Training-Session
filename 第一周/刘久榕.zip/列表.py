#你可以对列表的数据项进行修改或更新，你也可以使用 append() 方法来添加列表项，

list = ['Google', 'Runoob', 1997, 2000]

print ("第三个元素为 : ", list[2])
list[2] = 2001
print ("更新后的第三个元素为 : ", list[2])

#append()：在列表末尾添加单个元素
list1 = ['Google', 'Runoob', 'Taobao']
list1.append('Baidu')
print ("更新后的列表 : ", list1)

#insert()：在指定索引处插入元素
#语法：list.insert(index, object)
lst = [1, 3, 4]
lst.insert(1, 2)  # 在索引1处插入2
print(lst)  # 输出: [1, 2, 3, 4]

#extend()：在列表末尾一次性追加另一个可迭代对象的所有元素
#注意：extend() 与加号（+）不同，extend() 是原地修改，且不会生成新列表。
lst = [1, 2, 3]
lst.extend([4, 5])
print(lst)  # 输出: [1, 2, 3, 4, 5]

#pop()：删除并返回指定位置的元素，默认删除最后一个
lst = [10, 20, 30, 40]
item = lst.pop()    # 不传参数时，默认删除最后一个
print(item)         # 输出: 40
item = lst.pop(1)   # 删除索引1处的元素
print(item)         # 输出: 20
print(lst)          # 输出: [10, 30]

#remove()：删除指定值的第一个匹配项
lst = [1, 2, 3, 2, 4]
lst.remove(2)  # 只删除第一次出现的2
print(lst)     # 输出: [1, 3, 2, 4]

#sort()：原地排序列表
lst = [3, 1, 4, 2]
lst.sort()         # 升序排序
print(lst)         # 输出: [1, 2, 3, 4]
lst.sort(reverse=True)  # 降序排序
print(lst)         # 输出: [4, 3, 2, 1]
#reverse()：原地反转列表顺序
lst = [1, 2, 3, 4]
lst.reverse()
print(lst)  # 输出: [4, 3, 2, 1]

#列表推导式是一种简洁生成列表的方法，格式为：
even_nums = [x for x in range(10) if x % 2 == 0]
print(even_nums)  # 输出: [0, 2, 4, 6, 8]