#模式匹配是一种在编程中处理数据结构的方式，可以使代码更简洁、易读。
#在 Python 的 match...case 结构中，当 case pattern1: 这一分支被触发时，就表示当前要匹配的值（expression）与 pattern1 相符合。
#match语句后跟一个表达式，然后使用case语句来定义不同的模式。
#case后跟一个模式，可以是具体值、变量、通配符等。
def point_location(point):
    match point:
        case (0, 0):
            return "Origin"
        case (0, y):
            return f"Y-axis at y={y}"
        case (x, 0):
            return f"X-axis at x={x}"
        case (x, y):
            return f"Point at x={x}, y={y}"

print(point_location((0, 0)))   # 输出: Origin
print(point_location((0, 5)))   # 输出: Y-axis at y=5
print(point_location((3, 0)))   # 输出: X-axis at x=3
print(point_location((3, 4)))   # 输出: Point at x=3, y=4

#可以在 case 后使用 if 条件进一步限制匹配条件。例如：
def describe_number(n):
    match n:
        case int() if n < 0:
            return "Negative integer"
        case int() if n == 0:
            return "Zero"
        case int() if n > 0:
            return "Positive integer"
        case _:
            return "Not an integer"

print(describe_number(-10))  # 输出: Negative integer
print(describe_number(0))    # 输出: Zero
print(describe_number(42))   # 输出: Positive integer
print(describe_number(3.14)) # 输出: Not an integer

def process_item(item):
    match item:
        case {"type": "point", "x": x, "y": y}:
            return f"Point at ({x}, {y})"
        case {"type": "circle", "radius": r}:
            return f"Circle with radius {r}"
        case [first, *rest]:
            return f"List with first element {first} and rest {rest}"
        case _:
            return "Unknown item"

item1 = {"type": "point", "x": 10, "y": 20}#第一个 case 匹配字典，其键 "type" 必须为 "point"
item2 = {"type": "circle", "radius": 5}
item3 = [1, 2, 3, 4]

print(process_item(item1))  # 输出: Point at (10, 20)
print(process_item(item2))  # 输出: Circle with radius 5
print(process_item(item3))  # 输出: List with first element 1 and rest [2, 3, 4]

'''
while <expr>:
    <statement(s)>
else:
    <additional_statement(s)>#直接输出了
'''
count = 0
while count < 5:
   print (count, " 小于 5")
   count = count + 1
else:
   print (count, " 大于或等于 5")


'''
for item in iterable:
    # 循环主体
else:
    # 循环结束后执行的代码
'''
for x in range(6):
  print(x)
else:
  print("Finally finished!")

#以下 for 实例中使用了 break 语句，break 语句用于跳出当前循环体，不会执行 else 子句：
for x in range(6):  
  print(x)
  if x == 3:#触发break的条件
    break
else:
  print("Finally finished!") # 不会执行


sites = ["Baidu", "Google","Runoob","Taobao"]
for site in sites:
    if site == "Runoob":
        print("菜鸟教程!")
        break
    print("循环数据 " + site)
else:
    print("没有循环数据!")#使用 break 后，else 不会执行
print("完成循环!")


'''
break：用于提前退出整个循环。
continue：用于跳过当前迭代中剩余的代码，直接进入下一次循环。
else 子句：这个 else 子句会在循环“正常”结束后执行，
即当循环遍历完所有元素（或条件变为 False）且没有被 break 中断时才会执行。
'''
# 示例：只打印奇数，遇到偶数时跳过打印
for i in range(10):
    if i % 2 == 0:
        continue  # 跳过本次循环后面的代码,注意是本次
    print(i)


'''
什么是 pass？
空操作
pass 语句的唯一作用就是在需要语句却不想执行任何动作时占个位置。
程序在执行到 pass 时不会有任何副作用，也不会改变状态。

占位符
在编写代码时，我们可能需要定义一个函数、类或者控制结构，
但暂时还没想好具体的实现内容，此时可以使用 pass 占据位置，以确保代码的语法正确。

在编写代码时，有时你知道某个部分未来会补充代码，但当前你还没有实现。
此时用 pass 使代码结构完整，方便后续补全。

pass 既不会跳过循环，也不会退出循环，它只是“静静地”占据位置
'''
def process_data(data):
    # 以后在这里添加数据处理逻辑
    pass

# 现在先调用函数不会报错
process_data([1, 2, 3])


#end 关键字
#关键字end可以用于将结果输出到同一行，或者在输出的末尾添加不同的字符，实例如下：

# Fibonacci series: 斐波纳契数列
# 两个元素的总和确定了下一个数
a, b = 0, 1
while b < 1000:
    print(b, end=',')
    a, b = b, a+b