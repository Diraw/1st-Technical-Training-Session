'''
迭代器是一个可以记住遍历的位置的对象。

迭代器对象从集合的第一个元素开始访问，直到所有的元素被访问完结束。迭代器只能往前不会后退。

迭代器有两个基本的方法：iter() 和 next()。

字符串，列表或元组对象都可用于创建迭代器：
'''
numbers = [1, 2, 3, 4]  # 定义一个数字列表
iterator = iter(numbers)  # 创建迭代器对象
print(next(iterator))  # 输出迭代器的下一个元素

print(next(iterator))

class MyNumbers:
  # 定义迭代器对象的初始化方法
  def __iter__(self):#初始化迭代器对象。
    self.a = 1#相当于初始化迭代的起点。
    return self
  
  # 定义获取下一个值的方法
  def __next__(self):
    x = self.a
    self.a += 1
    return x
  
myclass = MyNumbers()
myiter = iter(myclass)
 
print(next(myiter))
print(next(myiter))
print(next(myiter))
print(next(myiter))
print(next(myiter))


'''
StopIteration
StopIteration 异常用于标识迭代的完成，防止出现无限循环的情况，
在 __next__() 方法中我们可以设置在完成指定循环次数后触发 StopIteration 异常来结束迭代。

在 20 次迭代后停止执行：
'''
class MyNumbers:
  def __iter__(self):
    self.a = 1
    return self
 
  def __next__(self):
    if self.a <= 20:
      x = self.a
      self.a += 1
      return x
    else:
      raise StopIteration
 
myclass = MyNumbers()
myiter = iter(myclass)
 
for x in myiter:
  print(x)

'''
从某种程度上说，迭代器与循环（如 while 循环）都涉及“逐个获取下一元素、直到没有元素或满足某条件时停止”的过程，
因此可以把“迭代的过程”想象成“不断调用 next() 的 while 循环”。
但是它们并不完全等价，迭代器是一种对象，而while 是一种流程控制语句。
迭代器本身并不直接“执行”循环，而是提供了“获取下一个值”的机制。
当你在 for 循环或调用 next(迭代器) 时，底层才会去调用迭代器的 __next__() 方法来拿到下一个元素。
'''


def fibonacci():
    """生成斐波那契数列的生成器"""
    a, b = 0, 1
    while True:
        yield a  # 返回当前的斐波那契数
        a, b = b, a + b

# 使用生成器表达式：只获取前10个斐波那契数
fib = fibonacci()
for _ in range(10):
    print(next(fib))
