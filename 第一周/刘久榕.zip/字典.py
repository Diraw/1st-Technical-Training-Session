'''
字典值可以是任何的 python 对象，既可以是标准的对象，也可以是用户定义的，但键不行。

两个重要的点需要记住：


1）不允许同一个键出现两次。创建时如果同一个键被赋值两次，后一个值会被记住，如下实例：'
'''
#!/usr/bin/python3
 
tinydict = {'Name': 'Runoob', 'Age': 7, 'Name': '小菜鸟'}
 
print ("tinydict['Name']: ", tinydict['Name'])

#键必须不可变，所以可以用数字，字符串或元组充当，而用列表就不行，如下实例：

tinydict = {['Name']: 'Runoob', 'Age': 7}
 
print ("tinydict['Name']: ", tinydict[['Name']])
#TypeError: unhashable type: 'list'

#fromkeys(seq, value=None)
#根据可迭代对象 seq 中的每个元素作为键，
# 创建一个新字典，所有键对应的初始值均为 value。
keys = ['a', 'b', 'c']
new_dict = dict.fromkeys(keys, 0)
print(new_dict)  # 输出: {'a': 0, 'b': 0, 'c': 0}

#get(key, default=None)
#返回指定键对应的值；如果键不存在，则返回默认值 default（默认返回 None）。
info = {'name': 'Alice', 'age': 30}
print(info.get('name'))        # 输出: Alice
print(info.get('city', 'N/A'))   # 输出: N/A

#pop(key[, default])
#删除指定键，并返回对应的值；如果键不存在，可以返回默认值，否则会引发 KeyError 异常。
info = {'name': 'Alice', 'age': 30}
age = info.pop('age')
print(age)   # 输出: 30
print(info)  # 输出: {'name': 'Alice'}

# 键不存在时，返回默认值
gender = info.pop('gender', 'unknown')
print(gender)  # 输出: unknown

#items()
#返回字典中所有键值对组成的视图对象，可以转换为列表或直接用于迭代。

info = {'name': 'Alice', 'age': 30}
for key, value in info.items():
    print(key, value)
# 输出:
# name Alice
# age 30

#keys() 和 values()
#分别返回字典所有的键和值的视图对象。

info = {'name': 'Alice', 'age': 30}
print(list(info.keys()))    # 输出: ['name', 'age']
print(list(info.values()))  # 输出: ['Alice', 30]